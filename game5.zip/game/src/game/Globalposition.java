package game;
public class Globalposition {
	public int x;
	public int y;
	public Globalposition(int x,int y)
	{
		this.x=x;
		this.y=y;
	}
}
