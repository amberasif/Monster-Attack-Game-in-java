package game;
public class Node {
		public int timetaken;
		public int totalscore;
		public String name;
		public Node next;
		
}